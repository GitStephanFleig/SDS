# Group 30: Final Project SDS2019

Project url: https://github.com/fleigst/SDS/

To run the project files:

01. Crawling.ipynb: Includes the crawling and data quality part
02. Data Structuring.ipynb: Includes the data preparation, tidying and descriptive analysis
03. Plots_positive and negative: Plots
04. Sentiment_plots: Plots
05. Feature Engineering.ipynb
06. Model Training.ipynb: This does not contain code.
07. BN - BinaryLogReg.ipynb
08. MT - Random Forest.ipynb
09. MT - KNN.ipynb
10. Best Model Selection.ipynb
